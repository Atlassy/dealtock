import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Lock, Mail, Package, Globe, UserPlus, ShieldAlert } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { dashboardTexts } from '@/lib/dashboardTexts'; 

const languages = {
  fr: { name: 'Français', flag: '🇫🇷' },
  en: { name: 'English', flag: '🇬🇧' },
  ar: { name: 'العربية', flag: '🇲🇦' },
};

const passwordRequirements = {
  minLength: 8,
  uppercase: /[A-Z]/,
  lowercase: /[a-z]/,
  number: /[0-9]/,
  specialChar: /[\W_]/, 
};

export function LoginForm({ onLogin, appLanguage, setAppLanguage }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [passwordErrors, setPasswordErrors] = useState([]);

  const { toast } = useToast();
  const currentTexts = dashboardTexts[appLanguage] || dashboardTexts.fr;

  const validatePassword = (pwd) => {
    const errors = [];
    if (pwd.length < passwordRequirements.minLength) {
      errors.push(currentTexts.passwordErrorMinLength(passwordRequirements.minLength));
    }
    if (!passwordRequirements.uppercase.test(pwd)) {
      errors.push(currentTexts.passwordErrorUppercase);
    }
    if (!passwordRequirements.lowercase.test(pwd)) {
      errors.push(currentTexts.passwordErrorLowercase);
    }
    if (!passwordRequirements.number.test(pwd)) {
      errors.push(currentTexts.passwordErrorNumber);
    }
    if (!passwordRequirements.specialChar.test(pwd)) {
      errors.push(currentTexts.passwordErrorSpecialChar);
    }
    setPasswordErrors(errors);
    return errors.length === 0;
  };

  const handlePasswordChange = (e) => {
    const newPassword = e.target.value;
    setPassword(newPassword);
    if (isRegistering) {
      validatePassword(newPassword);
    } else {
      setPasswordErrors([]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: currentTexts.errorLoginFailed,
        description: currentTexts.errorFillFields,
        variant: "destructive"
      });
      return;
    }

    if (isRegistering && !validatePassword(password)) {
      toast({
        title: currentTexts.errorRegistrationFailed,
        description: currentTexts.errorInvalidPassword,
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    try {
      if (isRegistering) {
        // Simuler la création de compte
        // Dans une vraie app, appeler une API d'inscription ici
        await new Promise(resolve => setTimeout(resolve, 1000)); 
        toast({
          title: currentTexts.successRegistrationTitle,
          description: currentTexts.successRegistrationMessage,
        });
        setIsRegistering(false); // Revenir au formulaire de connexion après inscription
        setEmail(''); // Optionnel: vider les champs
        setPassword('');
      } else {
        await onLogin(email, password);
        toast({
          title: currentTexts.successLogin,
          description: currentTexts.successWelcome
        });
      }
    } catch (error) {
      toast({
        title: isRegistering ? currentTexts.errorRegistrationFailed : currentTexts.errorLoginFailed,
        description: isRegistering ? currentTexts.errorRegistrationGeneric : currentTexts.errorCheckCredentials,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-slate-900" dir={appLanguage === 'ar' ? 'rtl' : 'ltr'}>
      <div className="absolute top-4 right-4 z-20">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="glass-effect border-white/20 text-white hover:bg-white/10 hover:text-white">
              <Globe className="mr-2 h-4 w-4" /> {languages[appLanguage].flag}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="glass-effect border-white/20 text-white">
            {Object.entries(languages).map(([code, lang]) => (
              <DropdownMenuItem key={code} onClick={() => setAppLanguage(code)} className="hover:bg-white/10">
                {lang.flag} {lang.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl floating-animation"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl floating-animation" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-green-500/10 rounded-full blur-3xl floating-animation" style={{ animationDelay: '4s' }}></div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        <Card className="glass-effect border-white/20 shadow-2xl">
          <CardHeader className="text-center space-y-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center pulse-glow"
            >
              <Package className="w-8 h-8 text-white" />
            </motion.div>
            <CardTitle className="text-3xl font-bold gradient-text">
              {currentTexts.appName}
            </CardTitle>
            <CardDescription className="text-gray-300">
              {isRegistering ? currentTexts.registrationDescription : currentTexts.description}
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <motion.div
                initial={{ opacity: 0, x: appLanguage === 'ar' ? 20 : -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="space-y-2"
              >
                <div className="relative">
                  <Mail className={`absolute ${appLanguage === 'ar' ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400`} />
                  <Input
                    type="email"
                    placeholder={currentTexts.emailPlaceholder}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`${appLanguage === 'ar' ? 'pr-10' : 'pl-10'} glass-effect border-white/20 focus:border-purple-500/50 text-white placeholder-gray-400`}
                    required
                  />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: appLanguage === 'ar' ? 20 : -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="space-y-2"
              >
                <div className="relative">
                  <Lock className={`absolute ${appLanguage === 'ar' ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400`} />
                  <Input
                    type="password"
                    placeholder={currentTexts.passwordPlaceholder}
                    value={password}
                    onChange={handlePasswordChange}
                    className={`${appLanguage === 'ar' ? 'pr-10' : 'pl-10'} glass-effect border-white/20 focus:border-purple-500/50 text-white placeholder-gray-400 ${passwordErrors.length > 0 && isRegistering ? 'border-red-500' : ''}`}
                    required
                  />
                </div>
                {isRegistering && passwordErrors.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {passwordErrors.map((error, index) => (
                      <div key={index} className="flex items-center text-xs text-red-400">
                        <ShieldAlert className="w-4 h-4 mr-1 flex-shrink-0" />
                        {error}
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>{isRegistering ? currentTexts.registeringButton : currentTexts.loadingButton}</span>
                    </div>
                  ) : (
                    isRegistering ? currentTexts.registerButton : currentTexts.loginButton
                  )}
                </Button>
              </motion.div>
            </form>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="mt-6 text-center"
            >
              <Button
                variant="link"
                onClick={() => {
                  setIsRegistering(!isRegistering);
                  setPasswordErrors([]); // Reset errors when switching forms
                }}
                className="text-purple-300 hover:text-purple-200"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                {isRegistering ? currentTexts.alreadyHaveAccount : currentTexts.createNewAccount}
              </Button>
              {!isRegistering && (
                <p className="text-sm text-gray-400 mt-2">
                  {currentTexts.demoHint}
                </p>
              )}
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}