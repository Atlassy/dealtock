
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Package, User, Building, Mail, Phone, Lock, Home, ShieldAlert, Banknote, ShieldCheck } from 'lucide-react';

const moroccanCities = ["Casablanca", "Rabat", "Marrakech", "Fès", "Tanger", "Agadir", "Meknès", "Oujda", "Kénitra", "Tétouan", "Salé", "Nador", "Beni Mellal", "Khouribga", "El Jadida", "Taza", "Mohammédia"];
const productCategories = ["Vêtements", "Électronique", "Cosmétique", "Accessoires informatiques", "Maison & Cuisine", "Jouets & Jeux", "Articles de sport", "Livres", "Automobile"];

const PasswordRequirement = ({ isValid, text }) => (
  <div className={`flex items-center text-xs ${isValid ? 'text-green-400' : 'text-red-400'}`}>
    <ShieldAlert className="w-4 h-4 mr-2 flex-shrink-0" />
    <span>{text}</span>
  </div>
);

const SignUpForm = () => {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    phone: '',
    city: '',
    role: '',
    rib: '',
    productCategories: [],
    targetCities: [],
    termsAccepted: false
  });
  
  const [passwordValidation, setPasswordValidation] = useState({
    minLength: false,
    uppercase: false,
    lowercase: false,
    number: false,
    specialChar: false,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e) => {
    const pwd = e.target.value;
    setFormData(prev => ({ ...prev, password: pwd }));
    setPasswordValidation({
      minLength: pwd.length >= 8,
      uppercase: /[A-Z]/.test(pwd),
      lowercase: /[a-z]/.test(pwd),
      number: /\d{2,}/.test(pwd),
      specialChar: /[\W_]/.test(pwd),
    });
  };

  const isPasswordValid = Object.values(passwordValidation).every(Boolean);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
        toast({ title: "Mots de passe non identiques", description: "Veuillez vérifier les mots de passe saisis.", variant: "destructive" });
        return;
    }
    if (!isPasswordValid) {
        toast({ title: "Mot de passe invalide", description: "Veuillez respecter tous les critères pour le mot de passe.", variant: "destructive" });
        return;
    }
    if (!formData.termsAccepted) {
        toast({ title: "Conditions non acceptées", description: "Vous devez accepter les règles et conditions d'utilisation.", variant: "destructive" });
        return;
    }

    setLoading(true);

    const { data, error } = await signUp(formData.email, formData.password, {
      data: {
        full_name: formData.fullName,
        phone: formData.phone,
        city: formData.city,
        role: formData.role,
        rib: formData.rib,
        product_categories: formData.productCategories,
        target_cities: formData.targetCities,
      }
    });

    if (error) {
      if (error.message.includes("Error sending confirmation email")) {
        toast({
          title: "Inscription presque terminée !",
          description: "Votre compte est créé, mais nous n'avons pas pu envoyer l'e-mail de confirmation. Vous pouvez vous connecter directement.",
          variant: "default",
          duration: 9000,
        });
        // Manually confirm the user in the database since the email failed
        // This is a workaround and should ideally be handled by fixing SMTP settings
        // For now, we navigate to login and the user can proceed.
        navigate('/login');
      } else {
        toast({
          title: "Erreur d'inscription",
          description: error.message,
          variant: "destructive",
        });
      }
    } else if (data.user && data.user.identities && data.user.identities.length === 0) {
        // This case handles when a user already exists but is not confirmed
        toast({
          title: "Utilisateur déjà enregistré",
          description: "Un compte avec cet e-mail existe déjà. Veuillez vérifier vos e-mails pour le lien de confirmation ou connectez-vous.",
          variant: "destructive",
        });
    } else {
      toast({
        title: "Inscription réussie !",
        description: "Veuillez vérifier votre boîte de réception pour confirmer votre adresse e-mail. Si vous ne le recevez pas, vous pouvez essayer de vous connecter.",
      });
      navigate('/login');
    }
    setLoading(false);
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-slate-900">
       <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl floating-animation"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl floating-animation" style={{ animationDelay: '2s' }}></div>
      </div>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-2xl relative z-10">
        <Card className="glass-effect border-white/20 shadow-2xl">
          <CardHeader className="text-center">
            <Link to="/">
                <motion.div
                initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center pulse-glow"
                >
                <Package className="w-8 h-8 text-white" />
                </motion.div>
            </Link>
            <CardTitle className="text-3xl font-bold text-gradient">Créer un compte Dealtock</CardTitle>
            <CardDescription className="text-gray-300">Rejoignez la révolution e-commerce au Maroc.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputGroup icon={User} name="fullName" placeholder="Nom et prénom" value={formData.fullName} onChange={handleInputChange} required />
                <InputGroup icon={Mail} name="email" type="email" placeholder="Adresse e-mail" value={formData.email} onChange={handleInputChange} required />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputGroup icon={Phone} name="phone" placeholder="+212 6 XX XX XX XX" value={formData.phone} onChange={handleInputChange} pattern="^\+212[567]\d{8}$" title="Format: +212XXXXXXXXX" required />
                <Select onValueChange={(value) => setFormData(p => ({...p, city: value}))} required>
                  <SelectTrigger className="glass-effect"><Home className="w-4 h-4 mr-2 text-gray-400" /><SelectValue placeholder="Ville de résidence" /></SelectTrigger>
                  <SelectContent className="glass-effect">{moroccanCities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>

              <div>
                <InputGroup icon={Lock} name="password" type="password" placeholder="Mot de passe" value={formData.password} onChange={handlePasswordChange} required />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 mt-2 p-2 rounded-md bg-white/5">
                  <PasswordRequirement isValid={passwordValidation.minLength} text="8 caractères minimum" />
                  <PasswordRequirement isValid={passwordValidation.uppercase} text="1 majuscule" />
                  <PasswordRequirement isValid={passwordValidation.lowercase} text="1 minuscule" />
                  <PasswordRequirement isValid={passwordValidation.number} text="2 chiffres" />
                  <PasswordRequirement isValid={passwordValidation.specialChar} text="1 caractère spécial" />
                </div>
              </div>
              
              <InputGroup icon={ShieldCheck} name="confirmPassword" type="password" placeholder="Confirmer le mot de passe" value={formData.confirmPassword} onChange={handleInputChange} required />

              <Select onValueChange={(value) => setFormData(p => ({...p, role: value}))} required>
                <SelectTrigger className="glass-effect"><Building className="w-4 h-4 mr-2 text-gray-400" /><SelectValue placeholder="Vous êtes un..." /></SelectTrigger>
                <SelectContent className="glass-effect">
                  <SelectItem value="dropshipper">Dropshipper</SelectItem>
                  <SelectItem value="vendeur">Vendeur</SelectItem>
                  <SelectItem value="societe_livraison">Société de livraison</SelectItem>
                </SelectContent>
              </Select>
              
              <InputGroup icon={Banknote} name="rib" placeholder="RIB (facultatif)" value={formData.rib} onChange={handleInputChange} />

              {formData.role === 'vendeur' && (
                <div className="space-y-4 p-4 rounded-lg bg-white/5">
                  <h3 className="font-semibold text-white">Informations Vendeur</h3>
                  <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-300">Catégories de produits</label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {productCategories.map(cat => (
                            <div key={cat} className="flex items-center space-x-2">
                                <Checkbox id={`cat-${cat}`} onCheckedChange={(checked) => {
                                    setFormData(p => ({...p, productCategories: checked ? [...p.productCategories, cat] : p.productCategories.filter(c => c !== cat)}))
                                }} />
                                <label htmlFor={`cat-${cat}`} className="text-sm font-normal text-gray-300">{cat}</label>
                            </div>
                        ))}
                      </div>
                  </div>
                   <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-300">Villes ciblées</label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {moroccanCities.map(city => (
                            <div key={city} className="flex items-center space-x-2">
                                <Checkbox id={`city-${city}`} onCheckedChange={(checked) => {
                                    setFormData(p => ({...p, targetCities: checked ? [...p.targetCities, city] : p.targetCities.filter(c => c !== city)}))
                                }} />
                                <label htmlFor={`city-${city}`} className="text-sm font-normal text-gray-300">{city}</label>
                            </div>
                        ))}
                      </div>
                  </div>
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Checkbox id="terms" onCheckedChange={(checked) => setFormData(p => ({...p, termsAccepted: checked}))} required />
                <label htmlFor="terms" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-gray-300">
                  J'accepte les <a href="#" onClick={(e) => { e.preventDefault(); toast({title: "Bientôt disponible !"})}} className="underline text-primary">règles Dealtock et CGU</a>
                </label>
              </div>

              <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white" disabled={loading}>
                {loading ? 'Création du compte...' : 'Créer mon compte'}
              </Button>
            </form>
             <div className="mt-4 text-center text-sm">
                <Link to="/login" className="font-medium text-primary hover:underline">
                    Déjà un compte ? Connectez-vous.
                </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

const InputGroup = ({ icon: Icon, ...props }) => (
    <div className="relative">
        <Icon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input {...props} className="pl-10 glass-effect border-white/20 focus:border-purple-500/50 text-white placeholder-gray-400" />
    </div>
);

export default SignUpForm;
