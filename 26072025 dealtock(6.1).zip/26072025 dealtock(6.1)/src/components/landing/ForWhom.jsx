import React from 'react';
import { motion } from 'framer-motion';
import { Store, ShoppingCart, Truck } from 'lucide-react';

const userTypes = [
  {
    icon: Store,
    title: "Vendeurs sur les réseaux sociaux",
    description: "Gérez vos boutiques Instagram, TikTok, Facebook sans vous soucier de la logistique."
  },
  {
    icon: Truck,
    title: "Sociétés de livraison e-commerce",
    description: "Externalisez les retours et gérez vos invendus efficacement."
  },
  {
    icon: ShoppingCart,
    title: "Dropshippers",
    description: "Restez focus sur le marketing, on gère vos produits et vos livraisons."
  }
];

const ForWhom = () => {
  return (
    <section id="for-whom" className="section-padding bg-background">
      <div className="container-large">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Un service pensé pour les acteurs du <span className="text-gradient">e-commerce</span>
          </h2>
        </motion.div>

        <div className="mt-16 grid max-w-lg gap-12 mx-auto lg:max-w-none lg:grid-cols-3">
          {userTypes.map((user, index) => (
            <motion.div 
              key={user.title} 
              className="flex flex-col overflow-hidden rounded-lg shadow-lg bg-secondary"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="flex-shrink-0 p-6">
                <user.icon className="h-12 w-12 text-primary" />
              </div>
              <div className="flex flex-1 flex-col justify-between p-6 pt-0">
                <div className="flex-1">
                  <p className="text-xl font-semibold text-foreground">{user.title}</p>
                  <p className="mt-3 text-base text-muted-foreground">{user.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ForWhom;