import React from 'react';
import { motion } from 'framer-motion';
import { Package, Box, Truck, BarChart, Banknote, Warehouse } from 'lucide-react';

const services = [
  { icon: Warehouse, title: "Stockage sécurisé", description: "Dans des garages aménagés." },
  { icon: Box, title: "Mise en vente directe", description: "Depuis nos points de stockage." },
  { icon: Package, title: "Préparation & emballage", description: "Professionnels et soignés." },
  { icon: Truck, title: "Expédition nationale rapide", description: "Via nos partenaires de confiance." },
  { icon: BarChart, title: "Suivi en temps réel", description: "Des stocks, ventes et livraisons." },
  { icon: Banknote, title: "Paiement par commission", description: "Sans frais de stockage mensuels." },
];

const WhatWeDo = () => {
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="what-we-do" className="section-padding bg-secondary">
      <div className="container-large">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Une solution complète pour votre e-commerce
          </h2>
          <p className="mt-4 max-w-3xl mx-auto text-lg text-muted-foreground">
            Que vous vendiez sur Jumia, Marketplace, Instagram ou via votre propre site, Dealtock vous propose une logistique fiable et locale. Nos mini-entrepôts au Maroc assurent un service clé en main.
          </p>
        </motion.div>

        <motion.div 
          className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {services.map((service, index) => (
            <motion.div key={index} variants={itemVariants} className="flex space-x-4">
              <div className="flex-shrink-0">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <service.icon className="h-6 w-6" aria-hidden="true" />
                </div>
              </div>
              <div>
                <p className="text-lg font-semibold text-foreground">{service.title}</p>
                <p className="mt-1 text-base text-muted-foreground">{service.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default WhatWeDo;