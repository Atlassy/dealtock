import React from 'react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Github, Twitter, Linkedin, MessageCircle } from 'lucide-react';

const Footer = () => {
  const { toast } = useToast();
  const currentYear = new Date().getFullYear();

  const handleNotImplemented = () => {
    toast({
      description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀",
    });
  };

  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container-large section-padding pb-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-1">
            <h3 className="text-xl font-bold text-gradient">Dealtock.pro</h3>
            <p className="mt-4 text-base text-muted-foreground">Solutions innovantes pour l’e-commerce national.</p>
            <div className="mt-8 flex space-x-6">
              <a href="#" onClick={handleNotImplemented} className="text-muted-foreground hover:text-primary"><span className="sr-only">GitHub</span><Github /></a>
              <a href="#" onClick={handleNotImplemented} className="text-muted-foreground hover:text-primary"><span className="sr-only">Twitter</span><Twitter /></a>
              <a href="#" onClick={handleNotImplemented} className="text-muted-foreground hover:text-primary"><span className="sr-only">LinkedIn</span><Linkedin /></a>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-8 md:col-span-2 md:grid-cols-3">
            <div>
              <p className="font-semibold text-foreground">Contactez-nous</p>
              <ul className="mt-4 space-y-2 text-sm">
                <li><a href="https://wa.me/212606730382" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">WhatsApp: +212 6 06 73 03 82</a></li>
                <li><a href="mailto:apv@dealtock.pro" className="text-muted-foreground hover:text-primary">Email: apv@dealtock.pro</a></li>
              </ul>
            </div>
            <div>
              <p className="font-semibold text-foreground">Villes couvertes</p>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                <li>Salé</li>
                <li>Kénitra</li>
                <li>Casablanca</li>
                <li>Marrakech</li>
              </ul>
            </div>
            <div>
              <p className="font-semibold text-foreground">Liens utiles</p>
              <ul className="mt-4 space-y-2 text-sm">
                <li><button onClick={handleNotImplemented} className="text-muted-foreground hover:text-primary text-left w-full">Règles & conditions</button></li>
                <li><button onClick={handleNotImplemented} className="text-muted-foreground hover:text-primary text-left w-full">Devenir partenaire</button></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-16 border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {currentYear} Dealtock.pro. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;