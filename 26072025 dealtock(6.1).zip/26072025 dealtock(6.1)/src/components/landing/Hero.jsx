import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Hero = () => {
  const { toast } = useToast();

  const handleNotImplemented = () => {
    toast({
      description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀",
    });
  };

  return (
    <section className="relative bg-background pt-40 pb-20">
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="container-large mx-auto text-center px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl md:text-6xl"
        >
          Simplifiez votre e-commerce avec <span className="text-gradient">Dealtock</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-6 max-w-md mx-auto text-lg text-muted-foreground sm:text-xl md:mt-8 md:max-w-2xl"
        >
          Transformez vos retours et invendus en revenus passifs grâce à notre réseau de points de vente physiques et en ligne.
        </motion.p>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-8 flex justify-center space-x-4"
        >
          <Button size="lg" variant="outline" onClick={handleNotImplemented}>Comment ça marche ?</Button>
          <Button size="lg" onClick={handleNotImplemented}>Devenir Partenaire</Button>
        </motion.div>
        <motion.div 
          className="mt-20"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.6 }}
        >
          <div className="relative aspect-video max-w-4xl mx-auto rounded-xl overflow-hidden shadow-2xl shadow-primary/20">
             <img  class="w-full h-full object-cover" alt="Un garage bien organisé avec étagères, cartons étiquetés, ambiance logistique moderne et propre." src="https://images.unsplash.com/photo-1549194388-f61be84a6e9e" />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;