import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const CTA = () => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleNotImplemented = () => {
    toast({
      description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀",
    });
  };

  return (
    <section className="bg-background">
      <div className="container-large section-padding">
        <motion.div 
          className="relative overflow-hidden rounded-2xl bg-primary/10 p-8 sm:p-12"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative">
            <h2 className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Prêt à faire passer votre commerce au <span className="text-gradient">niveau supérieur ?</span>
            </h2>
            <p className="mx-auto mt-6 max-w-2xl text-center text-lg text-muted-foreground">
              Des vendeurs et livreurs à travers le Maroc nous font déjà confiance. Pourquoi pas vous ?
            </p>
            <div className="mt-8 flex justify-center gap-4">
              <Button size="lg" onClick={() => navigate('/signup')}>
                🚀 Join Us
              </Button>
              <Button size="lg" variant="secondary" onClick={handleNotImplemented}>
                Demander un rappel
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTA;