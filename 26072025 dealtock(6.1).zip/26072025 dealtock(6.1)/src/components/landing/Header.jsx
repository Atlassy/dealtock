import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Globe } from 'lucide-react';

const Header = () => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleNotImplemented = () => {
    toast({
      description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀",
    });
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border"
    >
      <div className="container-large mx-auto flex h-20 items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="text-2xl font-bold text-gradient">
          Dealtock.pro
        </Link>
        <nav className="hidden md:flex items-center space-x-8">
          <a href="/#what-we-do" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Ce que nous faisons</a>
          <a href="/#for-whom" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Pour qui ?</a>
          <a href="/#why-us" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Pourquoi nous ?</a>
        </nav>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={handleNotImplemented}>
            <Globe className="h-4 w-4 mr-2" />
            FR
          </Button>
          <Button onClick={() => navigate('/login')}>Se connecter</Button>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;