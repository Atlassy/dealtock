import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Store, MessageCircle, GitBranchPlus } from 'lucide-react';

const features = [
  {
    icon: MapPin,
    title: "100% local et flexible",
    description: "Entrepôts proches de vos clients partout au Maroc pour une livraison ultra-rapide.",
  },
  {
    icon: Store,
    title: "Points de vente physiques",
    description: "Nos entrepôts peuvent également servir de lieux de vente directe et de click-and-collect.",
  },
  {
    icon: MessageCircle,
    title: "Support humain et réactif",
    description: "Un interlocuteur dédié via WhatsApp, téléphone ou en personne pour vous accompagner.",
  },
  {
    icon: GitBranchPlus,
    title: "Gestion intégrale",
    description: "Réception, inventaire, colisage, livraison – tout est automatisé pour vous faire gagner du temps.",
  },
];

const WhyChooseUs = () => {
  return (
    <section id="why-us" className="section-padding bg-secondary">
      <div className="container-large">
        <motion.div 
          className="lg:text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-base font-semibold uppercase tracking-wider text-primary">Notre Différence</h2>
          <p className="mt-2 text-3xl font-bold leading-8 tracking-tight text-foreground sm:text-4xl">
            Ce qui fait la différence Dealtock
          </p>
        </motion.div>
        <div className="mt-12">
          <dl className="space-y-10 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10 md:space-y-0">
            {features.map((feature, index) => (
              <motion.div 
                key={feature.title} 
                className="relative"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <dt>
                  <div className="absolute flex h-12 w-12 items-center justify-center rounded-md bg-primary text-primary-foreground">
                    <feature.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg font-medium leading-6 text-foreground">{feature.title}</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-muted-foreground">{feature.description}</dd>
              </motion.div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;