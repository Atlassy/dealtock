import React from 'react';
import { motion } from 'framer-motion';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader'; 
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { dashboardTexts } from '@/lib/dashboardTexts';
import { PackagePlus, UserPlus, BarChart2, TrendingUp, TrendingDown, PieChart, ListFilter, KeyRound, UserCog, Users } from 'lucide-react';

export function AdminDashboard({ user, onLogout, appLanguage, setAppLanguage }) {
  const { toast } = useToast();
  const currentTexts = dashboardTexts[appLanguage] || dashboardTexts.fr;

  const managementFeatures = [
    { titleKey: 'approveNewProductSubmissions', icon: PackagePlus, descriptionKey: "approveNewProductSubmissionsDesc" },
    { titleKey: 'approveNewUserRegistrations', icon: UserPlus, descriptionKey: "approveNewUserRegistrationsDesc" },
    { titleKey: 'userListAndCounters', icon: Users, descriptionKey: "userListAndCountersDesc"},
    { titleKey: 'resetUserPassword', icon: KeyRound, descriptionKey: "resetUserPasswordDesc" },
    { titleKey: 'addNewAdmin', icon: UserCog, descriptionKey: "addNewAdminDesc" },
  ];

  const analyticalFeatures = [
    { titleKey: 'topPerformingProducts', icon: TrendingUp, descriptionKey: "topPerformingProductsDesc" },
    { titleKey: 'lowPerformingProducts', icon: TrendingDown, descriptionKey: "lowPerformingProductsDesc" },
    { titleKey: 'overallPlatformStats', icon: PieChart, descriptionKey: "overallPlatformStatsDesc" },
  ];

  const handleFeatureClick = (titleKey) => {
    const featureTitle = currentTexts[titleKey] || currentTexts.adminDashboardTitle;
    let message = currentTexts.featureNotImplemented;
    
    if (appLanguage === 'ar') {
      message = `🚧 هذه الميزة (${featureTitle}) لم تنفذ بعد - ولكن لا تقلق! يمكنك طلبها في رسالتك القادمة! 🚀`;
    } else if (appLanguage === 'en') {
      message = `🚧 This feature (${featureTitle}) isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀`;
    } else {
      message = `🚧 Cette fonctionnalité (${featureTitle}) n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀`;
    }

    toast({
      title: featureTitle,
      description: message,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900/30 to-slate-900" dir={appLanguage === 'ar' ? 'rtl' : 'ltr'}>
      <DashboardHeader 
        user={user} 
        onLogout={onLogout} 
        appLanguage={appLanguage} 
        setAppLanguage={setAppLanguage} 
        texts={dashboardTexts}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2 gradient-text">
            {currentTexts.adminDashboardTitle}
          </h1>
          <p className="text-gray-300">
            {currentTexts.hello}, {user.name}! {currentTexts.welcomeMessageAdmin || currentTexts.welcomeMessage.replace("vos produits stockés chez", "la plateforme")} {user.company}.
          </p>
        </motion.div>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-semibold text-white mb-6 flex items-center">
            <ListFilter className="w-7 h-7 mr-3 text-purple-400" />
            {currentTexts.managementTasks}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {managementFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={`mgmt-${index}`} className="glass-effect border-white/20 card-hover cursor-pointer" onClick={() => handleFeatureClick(feature.titleKey)}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-lg font-semibold text-white">{currentTexts[feature.titleKey]}</CardTitle>
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">{currentTexts[feature.descriptionKey]}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </motion.section>
        
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-2xl font-semibold text-white mb-6 flex items-center">
            <BarChart2 className="w-7 h-7 mr-3 text-teal-400"/>
            {currentTexts.analyticalDashboard}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {analyticalFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={`anlytc-${index}`} className="glass-effect border-white/20 card-hover cursor-pointer" onClick={() => handleFeatureClick(feature.titleKey)}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-lg font-semibold text-white">{currentTexts[feature.titleKey]}</CardTitle>
                    <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-xl flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400">{currentTexts[feature.descriptionKey]}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </motion.section>

      </div>
    </div>
  );
}