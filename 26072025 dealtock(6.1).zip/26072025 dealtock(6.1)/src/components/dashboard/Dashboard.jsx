import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { useProducts } from '@/hooks/useProducts';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { StatsCards } from '@/components/dashboard/StatsCards';
import { ProductFilters } from '@/components/dashboard/ProductFilters';
import { ProductGrid } from '@/components/dashboard/ProductGrid';
import { ProductModals } from '@/components/dashboard/ProductModals';
import { AddProductModal } from '@/components/dashboard/AddProductModal';
import { dashboardTexts } from '@/lib/dashboardTexts';

export function Dashboard({ user, onLogout, appLanguage, setAppLanguage }) {
  const { products, isLoading, updateProductStatus, getStats, addProduct } = useProducts();
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [currentProduct, setCurrentProduct] = useState(null);
  const [isSoldModalOpen, setIsSoldModalOpen] = useState(false);
  const [isShippedModalOpen, setIsShippedModalOpen] = useState(false);
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);
  const [salePrice, setSalePrice] = useState('');
  const [carrier, setCarrier] = useState('');
  const [trackingLink, setTrackingLink] = useState('');
  const [deliveryProof, setDeliveryProof] = useState('');

  const { toast } = useToast();
  const stats = getStats();
  const currentTexts = dashboardTexts[appLanguage] || dashboardTexts.fr;

  const filteredProducts = selectedStatus === 'all' 
    ? products 
    : products.filter(product => product.status === selectedStatus);

  const handleStatusChange = (productId, newStatus, details = {}) => {
    updateProductStatus(productId, newStatus, details);
    toast({
      title: currentTexts.statusUpdateSuccessTitle,
      description: currentTexts.statusUpdateSuccessDescription
    });
    setIsSoldModalOpen(false);
    setIsShippedModalOpen(false);
    setCurrentProduct(null);
    setSalePrice('');
    setCarrier('');
    setTrackingLink('');
    setDeliveryProof('');
  };

  const openSoldModal = (product) => {
    setCurrentProduct(product);
    setSalePrice(product.salePrice || '');
    setIsSoldModalOpen(true);
  };

  const openShippedModal = (product) => {
    setCurrentProduct(product);
    setCarrier(product.carrier || '');
    setTrackingLink(product.trackingLink || '');
    setDeliveryProof(product.deliveryProof || '');
    setIsShippedModalOpen(true);
  };
  
  const handleOpenAddProductModal = () => {
    setIsAddProductModalOpen(true);
  };

  const handleAddNewProduct = (newProductData) => {
    try {
      addProduct(newProductData);
      toast({
        title: currentTexts.productSubmissionSuccessTitle,
        description: currentTexts.productSubmissionSuccessDesc,
      });
      setIsAddProductModalOpen(false);
    } catch (error) {
      toast({
        title: currentTexts.productSubmissionErrorTitle,
        description: currentTexts.productSubmissionErrorDesc,
        variant: "destructive",
      });
    }
  };


  const handleMarkAsSold = () => {
    if (!currentProduct || !salePrice) {
      toast({ title: currentTexts.errorTitle, description: currentTexts.errorEnterSalePrice, variant: "destructive" });
      return;
    }
    handleStatusChange(currentProduct.id, 'sold', { salePrice: parseFloat(salePrice) });
  };

  const handleMarkAsShipped = () => {
    if (!currentProduct || !carrier) {
      toast({ title: currentTexts.errorTitle, description: currentTexts.errorEnterCarrier, variant: "destructive" });
      return;
    }
    handleStatusChange(currentProduct.id, 'shipped', { carrier, trackingLink, deliveryProof });
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString(appLanguage, { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const formatPrice = (price) => {
    if (typeof price !== 'number') return 'N/A';
    return new Intl.NumberFormat(appLanguage, {
      style: 'currency',
      currency: 'EUR' 
    }).format(price);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center space-y-4"
        >
          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto"></div>
          <p className="text-gray-300">{currentTexts.loadingProducts}</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900" dir={appLanguage === 'ar' ? 'rtl' : 'ltr'}>
      <DashboardHeader 
        user={user} 
        onLogout={onLogout} 
        appLanguage={appLanguage} 
        setAppLanguage={setAppLanguage} 
        texts={dashboardTexts}
        onAddNewProduct={handleOpenAddProductModal}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold text-white mb-2">
            {currentTexts.hello}, {user.name}! 👋
          </h2>
          <p className="text-gray-300">
            {currentTexts.welcomeMessage} {user.company}
          </p>
        </motion.div>

        <StatsCards 
          stats={stats} 
          texts={dashboardTexts} 
          appLanguage={appLanguage} 
          formatPrice={formatPrice} 
        />

        <ProductFilters 
          selectedStatus={selectedStatus} 
          setSelectedStatus={setSelectedStatus} 
          texts={dashboardTexts} 
          appLanguage={appLanguage} 
        />

        <ProductGrid
          products={filteredProducts}
          texts={dashboardTexts}
          appLanguage={appLanguage}
          formatDate={formatDate}
          formatPrice={formatPrice}
          onOpenSoldModal={openSoldModal}
          onOpenShippedModal={openShippedModal}
          onStatusChange={handleStatusChange}
        />
      </div>

      <ProductModals
        isSoldModalOpen={isSoldModalOpen}
        setIsSoldModalOpen={setIsSoldModalOpen}
        isShippedModalOpen={isShippedModalOpen}
        setIsShippedModalOpen={setIsShippedModalOpen}
        currentProduct={currentProduct}
        salePrice={salePrice}
        setSalePrice={setSalePrice}
        carrier={carrier}
        setCarrier={setCarrier}
        trackingLink={trackingLink}
        setTrackingLink={setTrackingLink}
        deliveryProof={deliveryProof}
        setDeliveryProof={setDeliveryProof}
        onMarkAsSold={handleMarkAsSold}
        onMarkAsShipped={handleMarkAsShipped}
        texts={dashboardTexts}
        appLanguage={appLanguage}
      />
      <AddProductModal
        isOpen={isAddProductModalOpen}
        onClose={() => setIsAddProductModalOpen(false)}
        onAddProduct={handleAddNewProduct}
        texts={dashboardTexts}
        appLanguage={appLanguage}
      />
    </div>
  );
}