import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { PackagePlus } from 'lucide-react';

export function AddProductModal({ isOpen, onClose, onAddProduct, texts, appLanguage }) {
  const currentTexts = texts[appLanguage] || texts.fr;
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState('');
  const [value, setValue] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = () => {
    if (!productName || !category || !value || !location || !description) {
      // Basic validation, consider using a library for more complex forms
      // Or display individual error messages
      return; 
    }
    onAddProduct({
      name: productName,
      category,
      value: parseFloat(value),
      location,
      description,
    });
    // Reset form fields after submission
    setProductName('');
    setCategory('');
    setValue('');
    setLocation('');
    setDescription('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-effect border-white/20 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <PackagePlus className="mr-2 h-6 w-6 text-green-400" />
            {currentTexts.addNewProduct}
          </DialogTitle>
          <DialogDescription>{currentTexts.addNewProductDesc}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="productName" className="text-right text-gray-300">{currentTexts.productName}</Label>
            <Input
              id="productName"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              className="col-span-3 glass-effect border-white/20 placeholder-gray-500 text-white"
              placeholder={currentTexts.productName}
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="category" className="text-right text-gray-300">{currentTexts.productCategory}</Label>
            <Input
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="col-span-3 glass-effect border-white/20 placeholder-gray-500 text-white"
              placeholder={currentTexts.productCategory}
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="value" className="text-right text-gray-300">{currentTexts.productValue}</Label>
            <Input
              id="value"
              type="number"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="col-span-3 glass-effect border-white/20 placeholder-gray-500 text-white"
              placeholder="Ex: 250"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="location" className="text-right text-gray-300">{currentTexts.productLocation}</Label>
            <Input
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="col-span-3 glass-effect border-white/20 placeholder-gray-500 text-white"
              placeholder="Ex: Entrepôt A, Allée 5"
            />
          </div>
          <div className="grid grid-cols-4 items-start gap-4">
            <Label htmlFor="description" className="text-right text-gray-300 pt-2">{currentTexts.productDescription}</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="col-span-3 glass-effect border-white/20 placeholder-gray-500 text-white min-h-[80px]"
              placeholder={currentTexts.productDescription}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="glass-effect border-white/20 hover:bg-white/10 text-white">
            {currentTexts.cancel}
          </Button>
          <Button onClick={handleSubmit} className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white">
            {currentTexts.submitForApproval}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}