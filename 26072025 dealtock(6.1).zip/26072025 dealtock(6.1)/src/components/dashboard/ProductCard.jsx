import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import { Package, TrendingUp, Truck, MoreVertical, MapPin, Calendar, User, FileText, Link as LinkIcon, Clock } from 'lucide-react';

const statusDisplayConfig = {
  available: { color: 'status-available', icon: Package, textColor: 'text-green-100' },
  sold: { color: 'status-sold', icon: TrendingUp, textColor: 'text-orange-100' },
  shipped: { color: 'status-delivered', icon: Truck, textColor: 'text-purple-100' },
  pending_approval: { color: 'status-pending', icon: Clock, textColor: 'text-yellow-100' },
  default: { color: 'status-unknown', icon: Clock, textColor: 'text-gray-100' }
};

export function ProductCard({ product, index, texts, appLanguage, formatDate, formatPrice, onOpenSoldModal, onOpenShippedModal, onStatusChange }) {
  const currentTexts = texts[appLanguage] || texts.fr;
  const config = statusDisplayConfig[product.status] || statusDisplayConfig.default;
  const StatusIcon = config.icon;
  const { toast } = useToast();

  return (
    <motion.div
      key={product.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 * index }}
    >
      <Card className="glass-effect border-white/20 card-hover overflow-hidden">
        <div className="relative">
          <img   
            className="w-full h-48 object-cover"
            alt={`Image de ${product.name || 'produit'}`} src="https://images.unsplash.com/photo-1697201343043-06813d469611" />
          <div className="absolute top-4 right-4">
            <Badge className={`${config.color} ${config.textColor} border-0`}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {currentTexts[product.status] || product.status}
            </Badge>
          </div>
        </div>

        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <CardTitle className="text-lg text-white">{product.name}</CardTitle>
              <CardDescription className="text-gray-300">
                {product.category}
              </CardDescription>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="glass-effect border-white/20">
                <DropdownMenuLabel>{currentTexts.actions}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {(product.status === 'available' || product.status === 'pending_approval') && (
                  <>
                    <DropdownMenuItem onClick={() => onOpenSoldModal(product)}>
                      <TrendingUp className="mr-2 h-4 w-4" />
                      {currentTexts.markAsSold}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onOpenShippedModal(product)}>
                      <Truck className="mr-2 h-4 w-4" />
                      {currentTexts.markAsShipped}
                    </DropdownMenuItem>
                  </>
                )}
                {product.status === 'sold' && (
                  <DropdownMenuItem onClick={() => onOpenShippedModal(product)}>
                    <Truck className="mr-2 h-4 w-4" />
                    {currentTexts.markAsShipped}
                  </DropdownMenuItem>
                )}
                {product.status !== 'available' && product.status !== 'pending_approval' && (
                  <DropdownMenuItem onClick={() => onStatusChange(product.id, 'available')}>
                    <Package className="mr-2 h-4 w-4" />
                    {currentTexts.markAsAvailable}
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>

        <CardContent className="space-y-3">
          <div className="flex items-center text-sm text-gray-300">
            <MapPin className="w-4 h-4 mr-2 text-gray-400" />
            {product.location}
          </div>
          <div className="flex items-center text-sm text-gray-300">
            <Calendar className="w-4 h-4 mr-2 text-gray-400" />
            {currentTexts.entryDate} {formatDate(product.entryDate)}
          </div>

          {product.status === 'sold' && (
            <>
              <div className="flex items-center text-sm text-orange-300">
                <TrendingUp className="w-4 h-4 mr-2 text-orange-400" />
                {currentTexts.saleDate} {formatDate(product.saleDate)}
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{currentTexts.salePrice}:</span>
                <span className="font-semibold text-orange-300">{formatPrice(product.salePrice)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{currentTexts.commission}:</span>
                <span className="font-semibold text-red-400">{formatPrice(product.commission)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{currentTexts.netAmount}:</span>
                <span className="font-semibold text-green-400">{formatPrice(product.netAmount)}</span>
              </div>
            </>
          )}

          {product.status === 'shipped' && (
            <>
              <div className="flex items-center text-sm text-purple-300">
                <Truck className="w-4 h-4 mr-2 text-purple-400" />
                {currentTexts.shippingDate} {formatDate(product.shippingDate)}
              </div>
              <div className="flex items-center text-sm text-gray-300">
                <User className="w-4 h-4 mr-2 text-gray-400" />
                {currentTexts.carrier}: {product.carrier}
              </div>
              {product.trackingLink && (
                <div className="flex items-center text-sm text-gray-300">
                  <LinkIcon className="w-4 h-4 mr-2 text-gray-400" />
                  <a href={product.trackingLink} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                    {currentTexts.trackingLink}
                  </a>
                </div>
              )}
              {product.deliveryProof && (
                <div className="flex items-center text-sm text-gray-300">
                  <FileText className="w-4 h-4 mr-2 text-gray-400" />
                  <Button variant="link" className="p-0 h-auto text-blue-400 hover:underline" onClick={() => toast({ description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀" })}>
                    {currentTexts.viewProof} ({product.deliveryProof})
                  </Button>
                </div>
              )}
            </>
          )}
          
          <div className="flex justify-between items-center pt-3 border-t border-white/10 mt-3">
            <span className="text-sm text-gray-400">{currentTexts.value}</span>
            <span className="text-lg font-bold text-white">
              {formatPrice(product.value)}
            </span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}