import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuPortal } from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import { Package, LogOut, User, Globe, ShieldCheck, PlusCircle } from 'lucide-react';

const languages = {
  fr: { name: 'Français', flag: '🇫🇷' },
  en: { name: 'English', flag: '🇬🇧' },
  ar: { name: 'العربية', flag: '🇲🇦' },
};

export function DashboardHeader({ user, onLogout, appLanguage, setAppLanguage, texts, onAddNewProduct }) {
  const { toast } = useToast();
  const currentTexts = texts[appLanguage] || texts.fr;

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect border-b border-white/10 sticky top-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold gradient-text">{currentTexts.appName}</h1>
              <p className="text-sm text-gray-400">{currentTexts.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {!user.isAdmin && (
              <Button 
                onClick={onAddNewProduct} 
                className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                {currentTexts.addNewProduct}
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback className="bg-gradient-to-br from-purple-500 to-blue-500 text-white">
                      {user.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 glass-effect border-white/20 text-white" align="end">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none text-white">{user.name}</p>
                    <p className="text-xs leading-none text-gray-400">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-white/10" />
                <DropdownMenuItem onClick={() => toast({ description: currentTexts.featureNotImplemented })} className="hover:bg-white/10">
                  <User className="mr-2 h-4 w-4" />
                  <span>{currentTexts.profile}</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => toast({ description: currentTexts.featureNotImplemented })} className="hover:bg-white/10">
                  <ShieldCheck className="mr-2 h-4 w-4" />
                  <span>{currentTexts.updatePassword}</span>
                </DropdownMenuItem>
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="hover:bg-white/10">
                    <Globe className="mr-2 h-4 w-4" />
                    <span>{currentTexts.language}</span>
                  </DropdownMenuSubTrigger>
                  <DropdownMenuPortal>
                    <DropdownMenuSubContent className="glass-effect border-white/20 text-white">
                      <DropdownMenuRadioGroup value={appLanguage} onValueChange={setAppLanguage}>
                        {Object.entries(languages).map(([code, lang]) => (
                          <DropdownMenuRadioItem key={code} value={code} className="hover:bg-white/10">
                            {lang.flag} {lang.name}
                          </DropdownMenuRadioItem>
                        ))}
                      </DropdownMenuRadioGroup>
                    </DropdownMenuSubContent>
                  </DropdownMenuPortal>
                </DropdownMenuSub>
                <DropdownMenuSeparator className="bg-white/10"/>
                <DropdownMenuItem onClick={onLogout} className="hover:bg-red-500/20 text-red-400 hover:text-red-300">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{currentTexts.logout}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </motion.header>
  );
}