import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuPortal } from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import { useProducts } from '@/hooks/useProducts';
import { 
  Package, 
  TrendingUp, 
  Truck, 
  MoreVertical, 
  LogOut, 
  User, 
  Settings,
  MapPin,
  Calendar,
  Euro,
  Filter,
  FileText,
  Globe,
  Percent,
  ShieldCheck,
  Link as LinkIcon
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';


const statusConfig = {
  available: {
    label: 'Disponible',
    color: 'status-available',
    icon: Package,
    textColor: 'text-green-100'
  },
  sold: {
    label: 'Vendu',
    color: 'status-sold',
    icon: TrendingUp,
    textColor: 'text-orange-100'
  },
  shipped: {
    label: 'Expédié',
    color: 'status-delivered',
    icon: Truck,
    textColor: 'text-purple-100'
  }
};

const languages = {
  fr: { name: 'Français', flag: '🇫🇷' },
  en: { name: 'English', flag: '🇬🇧' },
  ar: { name: 'العربية', flag: '🇲🇦' },
};

export function Dashboard({ user, onLogout, appLanguage, setAppLanguage }) {
  const { products, isLoading, updateProductStatus, getStats } = useProducts();
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [currentProduct, setCurrentProduct] = useState(null);
  const [isSoldModalOpen, setIsSoldModalOpen] = useState(false);
  const [isShippedModalOpen, setIsShippedModalOpen] = useState(false);
  const [salePrice, setSalePrice] = useState('');
  const [carrier, setCarrier] = useState('');
  const [trackingLink, setTrackingLink] = useState('');
  const [deliveryProof, setDeliveryProof] = useState('');

  const { toast } = useToast();
  const stats = getStats();

  const filteredProducts = selectedStatus === 'all' 
    ? products 
    : products.filter(product => product.status === selectedStatus);

  const handleStatusChange = (productId, newStatus, details = {}) => {
    updateProductStatus(productId, newStatus, details);
    toast({
      title: "Statut mis à jour",
      description: `Le statut du produit a été modifié avec succès.`
    });
    setIsSoldModalOpen(false);
    setIsShippedModalOpen(false);
    setCurrentProduct(null);
    setSalePrice('');
    setCarrier('');
    setTrackingLink('');
    setDeliveryProof('');
  };

  const openSoldModal = (product) => {
    setCurrentProduct(product);
    setSalePrice(product.salePrice || '');
    setIsSoldModalOpen(true);
  };

  const openShippedModal = (product) => {
    setCurrentProduct(product);
    setCarrier(product.carrier || '');
    setTrackingLink(product.trackingLink || '');
    setDeliveryProof(product.deliveryProof || '');
    setIsShippedModalOpen(true);
  };

  const handleMarkAsSold = () => {
    if (!currentProduct || !salePrice) {
      toast({ title: "Erreur", description: "Veuillez entrer un prix de vente.", variant: "destructive" });
      return;
    }
    handleStatusChange(currentProduct.id, 'sold', { salePrice: parseFloat(salePrice) });
  };

  const handleMarkAsShipped = () => {
    if (!currentProduct || !carrier) {
      toast({ title: "Erreur", description: "Veuillez entrer le nom du transporteur.", variant: "destructive" });
      return;
    }
    handleStatusChange(currentProduct.id, 'shipped', { carrier, trackingLink, deliveryProof });
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString(appLanguage, { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const formatPrice = (price) => {
    if (typeof price !== 'number') return 'N/A';
    return new Intl.NumberFormat(appLanguage, {
      style: 'currency',
      currency: 'EUR' 
    }).format(price);
  };

  const texts = {
    fr: {
      title: "StockManager Pro",
      subtitle: "Gestion de produits",
      hello: "Bonjour",
      welcomeMessage: "Voici un aperçu de vos produits stockés chez",
      totalProducts: "Total Produits",
      available: "Disponibles",
      sold: "Vendus",
      shipped: "Expédiés",
      totalValue: "Valeur en Stock",
      totalSoldAmount: "Total Ventes",
      totalCommission: "Total Commissions",
      totalNetToReceive: "Net à Recevoir",
      allProducts: "Tous les produits",
      actions: "Actions",
      markAsSold: "Marquer comme vendu",
      markAsShipped: "Marquer comme expédié",
      markAsAvailable: "Remettre disponible",
      location: "Emplacement",
      entryDate: "Stocké le",
      saleDate: "Vendu le",
      shippingDate: "Expédié le",
      carrier: "Transporteur",
      trackingLink: "Lien de suivi",
      deliveryProof: "Preuve de livraison",
      value: "Valeur",
      salePrice: "Prix de vente",
      commission: "Commission (10%)",
      netAmount: "Montant net",
      noProductsFound: "Aucun produit trouvé",
      noProductsMatchFilters: "Aucun produit ne correspond aux filtres sélectionnés.",
      profile: "Profil",
      settings: "Paramètres",
      language: "Langue",
      logout: "Déconnexion",
      loadingProducts: "Chargement de vos produits...",
      updatePassword: "Modifier mot de passe",
      enterSalePrice: "Entrer le prix de vente",
      enterShippingInfo: "Entrer les informations d'expédition",
      product: "Produit",
      cancel: "Annuler",
      confirm: "Confirmer",
      viewProof: "Voir la preuve",
    },
    en: {
      title: "StockManager Pro",
      subtitle: "Product Management",
      hello: "Hello",
      welcomeMessage: "Here is an overview of your products stored at",
      totalProducts: "Total Products",
      available: "Available",
      sold: "Sold",
      shipped: "Shipped",
      totalValue: "Stock Value",
      totalSoldAmount: "Total Sales",
      totalCommission: "Total Commissions",
      totalNetToReceive: "Net to Receive",
      allProducts: "All products",
      actions: "Actions",
      markAsSold: "Mark as sold",
      markAsShipped: "Mark as shipped",
      markAsAvailable: "Mark as available",
      location: "Location",
      entryDate: "Stocked on",
      saleDate: "Sold on",
      shippingDate: "Shipped on",
      carrier: "Carrier",
      trackingLink: "Tracking link",
      deliveryProof: "Delivery proof",
      value: "Value",
      salePrice: "Sale price",
      commission: "Commission (10%)",
      netAmount: "Net amount",
      noProductsFound: "No products found",
      noProductsMatchFilters: "No products match the selected filters.",
      profile: "Profile",
      settings: "Settings",
      language: "Language",
      logout: "Logout",
      loadingProducts: "Loading your products...",
      updatePassword: "Update Password",
      enterSalePrice: "Enter sale price",
      enterShippingInfo: "Enter shipping information",
      product: "Product",
      cancel: "Cancel",
      confirm: "Confirm",
      viewProof: "View Proof",
    },
    ar: {
      title: "ستوك مانجر برو",
      subtitle: "إدارة المنتجات",
      hello: "مرحباً",
      welcomeMessage: "إليك نظرة عامة على منتجاتك المخزنة في",
      totalProducts: "إجمالي المنتجات",
      available: "متوفر",
      sold: "مباع",
      shipped: "تم الشحن",
      totalValue: "قيمة المخزون",
      totalSoldAmount: "إجمالي المبيعات",
      totalCommission: "إجمالي العمولات",
      totalNetToReceive: "صافي التحصيل",
      allProducts: "جميع المنتجات",
      actions: "الإجراءات",
      markAsSold: "وضع علامة كمباع",
      markAsShipped: "وضع علامة كتم الشحن",
      markAsAvailable: "إعادة للتوفر",
      location: "الموقع",
      entryDate: "خُزّن في",
      saleDate: "بِيع في",
      shippingDate: "شُحِن في",
      carrier: "شركة النقل",
      trackingLink: "رابط التتبع",
      deliveryProof: "إثبات التسليم",
      value: "القيمة",
      salePrice: "سعر البيع",
      commission: "العمولة (10%)",
      netAmount: "المبلغ الصافي",
      noProductsFound: "لم يتم العثور على منتجات",
      noProductsMatchFilters: "لا توجد منتجات تطابق الفلاتر المحددة.",
      profile: "الملف الشخصي",
      settings: "الإعدادات",
      language: "اللغة",
      logout: "تسجيل الخروج",
      loadingProducts: "جاري تحميل منتجاتك...",
      updatePassword: "تحديث كلمة المرور",
      enterSalePrice: "أدخل سعر البيع",
      enterShippingInfo: "أدخل معلومات الشحن",
      product: "المنتج",
      cancel: "إلغاء",
      confirm: "تأكيد",
      viewProof: "عرض الإثبات",
    }
  };

  const currentTexts = texts[appLanguage] || texts.fr;


  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center space-y-4"
        >
          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto"></div>
          <p className="text-gray-300">{currentTexts.loadingProducts}</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900" dir={appLanguage === 'ar' ? 'rtl' : 'ltr'}>
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-effect border-b border-white/10 sticky top-0 z-50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">{currentTexts.title}</h1>
                <p className="text-sm text-gray-400">{currentTexts.subtitle}</p>
              </div>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback className="bg-gradient-to-br from-purple-500 to-blue-500 text-white">
                      {user.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 glass-effect border-white/20" align="end">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => toast({ description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀" })}>
                  <User className="mr-2 h-4 w-4" />
                  <span>{currentTexts.profile}</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => toast({ description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀" })}>
                  <ShieldCheck className="mr-2 h-4 w-4" />
                  <span>{currentTexts.updatePassword}</span>
                </DropdownMenuItem>
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger>
                    <Globe className="mr-2 h-4 w-4" />
                    <span>{currentTexts.language}</span>
                  </DropdownMenuSubTrigger>
                  <DropdownMenuPortal>
                    <DropdownMenuSubContent className="glass-effect border-white/20">
                      <DropdownMenuRadioGroup value={appLanguage} onValueChange={setAppLanguage}>
                        {Object.entries(languages).map(([code, lang]) => (
                          <DropdownMenuRadioItem key={code} value={code}>
                            {lang.flag} {lang.name}
                          </DropdownMenuRadioItem>
                        ))}
                      </DropdownMenuRadioGroup>
                    </DropdownMenuSubContent>
                  </DropdownMenuPortal>
                </DropdownMenuSub>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{currentTexts.logout}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </motion.header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold text-white mb-2">
            {currentTexts.hello}, {user.name}! 👋
          </h2>
          <p className="text-gray-300">
            {currentTexts.welcomeMessage} {user.company}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.totalProducts}</p>
                  <p className="text-3xl font-bold text-white">{stats.total}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.available}</p>
                  <p className="text-3xl font-bold text-green-400">{stats.available}</p>
                </div>
                <div className="w-12 h-12 status-available rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.sold}</p>
                  <p className="text-3xl font-bold text-orange-400">{stats.sold}</p>
                </div>
                <div className="w-12 h-12 status-sold rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.shipped}</p>
                  <p className="text-3xl font-bold text-purple-400">{stats.shipped}</p>
                </div>
                <div className="w-12 h-12 status-delivered rounded-xl flex items-center justify-center">
                  <Truck className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.totalValue}</p>
                  <p className="text-2xl font-bold text-white">{formatPrice(stats.totalValue)}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                  <Euro className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.totalSoldAmount}</p>
                  <p className="text-2xl font-bold text-orange-300">{formatPrice(stats.totalSoldAmount)}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-amber-500 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.totalCommission}</p>
                  <p className="text-2xl font-bold text-red-400">{formatPrice(stats.totalCommission)}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Percent className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-white/20 card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-300">{currentTexts.totalNetToReceive}</p>
                  <p className="text-2xl font-bold text-teal-400">{formatPrice(stats.totalNetToReceive)}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center">
                  <Euro className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-wrap gap-4 mb-6"
        >
          <Button
            variant={selectedStatus === 'all' ? 'default' : 'outline'}
            onClick={() => setSelectedStatus('all')}
            className="glass-effect border-white/20"
          >
            <Filter className="w-4 h-4 mr-2" />
            {currentTexts.allProducts}
          </Button>
          {Object.entries(statusConfig).map(([status, config]) => (
            <Button
              key={status}
              variant={selectedStatus === status ? 'default' : 'outline'}
              onClick={() => setSelectedStatus(status)}
              className="glass-effect border-white/20"
            >
              <config.icon className="w-4 h-4 mr-2" />
              {currentTexts[status] || config.label}
            </Button>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredProducts.map((product, index) => {
            const config = statusConfig[product.status];
            const StatusIcon = config.icon;

            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
              >
                <Card className="glass-effect border-white/20 card-hover overflow-hidden">
                  <div className="relative">
                    <img 
                      className="w-full h-48 object-cover"
                      alt={`Image de ${product.name}`}
                     src="https://images.unsplash.com/photo-1671376354106-d8d21e55dddd" />
                    <div className="absolute top-4 right-4">
                      <Badge className={`${config.color} ${config.textColor} border-0`}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {currentTexts[product.status] || config.label}
                      </Badge>
                    </div>
                  </div>

                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-lg text-white">{product.name}</CardTitle>
                        <CardDescription className="text-gray-300">
                          {product.category}
                        </CardDescription>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="glass-effect border-white/20">
                          <DropdownMenuLabel>{currentTexts.actions}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          {product.status === 'available' && (
                            <>
                              <DropdownMenuItem onClick={() => openSoldModal(product)}>
                                <TrendingUp className="mr-2 h-4 w-4" />
                                {currentTexts.markAsSold}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => openShippedModal(product)}>
                                <Truck className="mr-2 h-4 w-4" />
                                {currentTexts.markAsShipped}
                              </DropdownMenuItem>
                            </>
                          )}
                          {product.status === 'sold' && (
                            <DropdownMenuItem onClick={() => openShippedModal(product)}>
                              <Truck className="mr-2 h-4 w-4" />
                              {currentTexts.markAsShipped}
                            </DropdownMenuItem>
                          )}
                          {product.status !== 'available' && (
                            <DropdownMenuItem onClick={() => handleStatusChange(product.id, 'available')}>
                              <Package className="mr-2 h-4 w-4" />
                              {currentTexts.markAsAvailable}
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <div className="flex items-center text-sm text-gray-300">
                      <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                      {product.location}
                    </div>
                    <div className="flex items-center text-sm text-gray-300">
                      <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                      {currentTexts.entryDate} {formatDate(product.entryDate)}
                    </div>

                    {product.status === 'sold' && (
                      <>
                        <div className="flex items-center text-sm text-orange-300">
                          <TrendingUp className="w-4 h-4 mr-2 text-orange-400" />
                          {currentTexts.saleDate} {formatDate(product.saleDate)}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-400">{currentTexts.salePrice}:</span>
                          <span className="font-semibold text-orange-300">{formatPrice(product.salePrice)}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-400">{currentTexts.commission}:</span>
                          <span className="font-semibold text-red-400">{formatPrice(product.commission)}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-400">{currentTexts.netAmount}:</span>
                          <span className="font-semibold text-green-400">{formatPrice(product.netAmount)}</span>
                        </div>
                      </>
                    )}

                    {product.status === 'shipped' && (
                      <>
                        <div className="flex items-center text-sm text-purple-300">
                          <Truck className="w-4 h-4 mr-2 text-purple-400" />
                          {currentTexts.shippingDate} {formatDate(product.shippingDate)}
                        </div>
                        <div className="flex items-center text-sm text-gray-300">
                          <User className="w-4 h-4 mr-2 text-gray-400" />
                          {currentTexts.carrier}: {product.carrier}
                        </div>
                        {product.trackingLink && (
                          <div className="flex items-center text-sm text-gray-300">
                            <LinkIcon className="w-4 h-4 mr-2 text-gray-400" />
                            <a href={product.trackingLink} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                              {currentTexts.trackingLink}
                            </a>
                          </div>
                        )}
                        {product.deliveryProof && (
                          <div className="flex items-center text-sm text-gray-300">
                            <FileText className="w-4 h-4 mr-2 text-gray-400" />
                            <Button variant="link" className="p-0 h-auto text-blue-400 hover:underline" onClick={() => toast({ description: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine requête ! 🚀" })}>
                              {currentTexts.viewProof} ({product.deliveryProof})
                            </Button>
                          </div>
                        )}
                      </>
                    )}
                    
                    <div className="flex justify-between items-center pt-3 border-t border-white/10 mt-3">
                      <span className="text-sm text-gray-400">{currentTexts.value}</span>
                      <span className="text-lg font-bold text-white">
                        {formatPrice(product.value)}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {filteredProducts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-300 mb-2">
              {currentTexts.noProductsFound}
            </h3>
            <p className="text-gray-400">
              {currentTexts.noProductsMatchFilters}
            </p>
          </motion.div>
        )}
      </div>

      {/* Modals */}
      <Dialog open={isSoldModalOpen} onOpenChange={setIsSoldModalOpen}>
        <DialogContent className="glass-effect border-white/20 text-white">
          <DialogHeader>
            <DialogTitle>{currentTexts.markAsSold}</DialogTitle>
            <DialogDescription>{currentTexts.enterSalePrice} {currentTexts.product.toLowerCase()} "{currentProduct?.name}".</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="salePrice" className="text-right">{currentTexts.salePrice}</Label>
              <Input
                id="salePrice"
                type="number"
                value={salePrice}
                onChange={(e) => setSalePrice(e.target.value)}
                className="col-span-3 glass-effect border-white/20"
                placeholder="Ex: 1500"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSoldModalOpen(false)} className="glass-effect border-white/20">{currentTexts.cancel}</Button>
            <Button onClick={handleMarkAsSold} className="bg-gradient-to-r from-orange-500 to-amber-500">{currentTexts.confirm}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isShippedModalOpen} onOpenChange={setIsShippedModalOpen}>
        <DialogContent className="glass-effect border-white/20 text-white">
          <DialogHeader>
            <DialogTitle>{currentTexts.markAsShipped}</DialogTitle>
            <DialogDescription>{currentTexts.enterShippingInfo} {currentTexts.product.toLowerCase()} "{currentProduct?.name}".</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="carrier" className="text-right">{currentTexts.carrier}</Label>
              <Input
                id="carrier"
                value={carrier}
                onChange={(e) => setCarrier(e.target.value)}
                className="col-span-3 glass-effect border-white/20"
                placeholder="Ex: Chronopost"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="trackingLink" className="text-right">{currentTexts.trackingLink}</Label>
              <Input
                id="trackingLink"
                value={trackingLink}
                onChange={(e) => setTrackingLink(e.target.value)}
                className="col-span-3 glass-effect border-white/20"
                placeholder="Ex: https://..."
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="deliveryProof" className="text-right">{currentTexts.deliveryProof}</Label>
              <Input
                id="deliveryProof"
                value={deliveryProof}
                onChange={(e) => setDeliveryProof(e.target.value)}
                className="col-span-3 glass-effect border-white/20"
                placeholder="Ex: signature.pdf ou photo.jpg"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsShippedModalOpen(false)} className="glass-effect border-white/20">{currentTexts.cancel}</Button>
            <Button onClick={handleMarkAsShipped} className="bg-gradient-to-r from-purple-500 to-indigo-500">{currentTexts.confirm}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}