import { useState, useEffect } from 'react';

const commissionRate = 0.1; // 10% commission

const initialMockProducts = [
  {
    id: '1',
    name: 'MacBook Pro 16"',
    category: 'Électronique',
    status: 'available', // 'available', 'pending_approval', 'sold', 'shipped'
    entryDate: '2024-01-15',
    location: 'Entrepôt A - Zone 1',
    value: 2499,
    description: 'MacBook Pro 16 pouces avec puce M3 Pro',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400',
    userId: 'userDemo123', // For associating with a user
  },
  {
    id: '2',
    name: 'Canapé en Cuir',
    category: 'Mobilier',
    status: 'sold',
    entryDate: '2024-01-10',
    saleDate: '2024-01-20',
    salePrice: 1350,
    location: 'Entrepôt B - Zone 3',
    value: 1200,
    description: 'Canapé 3 places en cuir véritable',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
    userId: 'userDemo456',
  },
   {
    id: '3',
    name: 'Vélo Électrique',
    category: 'Sport',
    status: 'shipped',
    entryDate: '2024-01-05',
    shippingDate: '2024-01-18',
    carrier: 'Chronopost',
    trackingLink: 'https://www.chronopost.fr/tracking-no-cms/suivi-page?listeNumerosLT=XY123456789FR',
    deliveryProof: 'signature_client.pdf',
    location: 'Entrepôt A - Zone 2',
    value: 1800,
    description: 'Vélo électrique urbain avec batterie longue durée',
    image: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=400',
    userId: 'userDemo123',
  },
];

const STORAGE_KEY = 'dealtock_products_v3';

export function useProducts() {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadProducts = () => {
      const savedProducts = localStorage.getItem(STORAGE_KEY);
      if (savedProducts) {
        setProducts(JSON.parse(savedProducts));
      } else {
        const processedMockProducts = initialMockProducts.map(p => {
          if (p.status === 'sold' && p.salePrice) {
            p.commission = p.salePrice * commissionRate;
            p.netAmount = p.salePrice - p.commission;
          }
          if (!p.status) p.status = 'available'; // Default status
          return p;
        });
        setProducts(processedMockProducts);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(processedMockProducts));
      }
      setIsLoading(false);
    };

    setTimeout(loadProducts, 1000); 
  }, []);

  const saveProducts = (updatedProducts) => {
    setProducts(updatedProducts);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedProducts));
  };

  const addProduct = (newProductData) => {
    if (!newProductData.name || !newProductData.category || !newProductData.value || !newProductData.location || !newProductData.description) {
      throw new Error("All fields are required");
    }
    const newProduct = {
      id: `product-${Date.now()}`,
      ...newProductData,
      status: 'pending_approval', // New products await admin approval
      entryDate: new Date().toISOString().split('T')[0],
      value: parseFloat(newProductData.value),
      image: newProductData.image || `https://source.unsplash.com/400x300/?${newProductData.category},product`, // Generic image
      userId: 'currentUser123' // Replace with actual user ID
    };
    saveProducts([...products, newProduct]);
  };

  const updateProductStatus = (productId, newStatus, details = {}) => {
    const updatedProducts = products.map(product => {
      if (product.id === productId) {
        const updatedProduct = { ...product, status: newStatus, ...details };
        
        if (newStatus === 'sold') {
          if (!product.saleDate) updatedProduct.saleDate = new Date().toISOString().split('T')[0];
          if (details.salePrice) {
            updatedProduct.commission = parseFloat(details.salePrice) * commissionRate;
            updatedProduct.netAmount = parseFloat(details.salePrice) - updatedProduct.commission;
          } else if (product.salePrice) { // Recalculate if salePrice was already there
            updatedProduct.commission = parseFloat(product.salePrice) * commissionRate;
            updatedProduct.netAmount = parseFloat(product.salePrice) - updatedProduct.commission;
          }
        }
        
        if (newStatus === 'shipped') {
          if (!product.shippingDate) updatedProduct.shippingDate = new Date().toISOString().split('T')[0];
        }

        if (newStatus === 'available') { // Reset sale/shipping specific data
            delete updatedProduct.saleDate;
            delete updatedProduct.salePrice;
            delete updatedProduct.commission;
            delete updatedProduct.netAmount;
            delete updatedProduct.shippingDate;
            delete updatedProduct.carrier;
            delete updatedProduct.trackingLink;
            delete updatedProduct.deliveryProof;
        }
        
        return updatedProduct;
      }
      return product;
    });
    
    saveProducts(updatedProducts);
  };

  const getProductsByStatus = (status) => {
    // If 'available', also include 'pending_approval' for user view, admin will differentiate
    if (status === 'available') {
        return products.filter(product => product.status === 'available' || product.status === 'pending_approval');
    }
    return products.filter(product => product.status === status);
  };

  const getTotalValue = () => {
    return products.filter(p => p.status === 'available' || p.status === 'pending_approval').reduce((total, product) => total + (product.value || 0), 0);
  };

  const getStats = () => {
    const availableCount = products.filter(p => p.status === 'available' || p.status === 'pending_approval').length;
    const soldCount = products.filter(p => p.status === 'sold').length;
    const shippedCount = products.filter(p => p.status === 'shipped').length;
    
    const totalValue = getTotalValue();
    const totalSoldAmount = products.filter(p => p.status === 'sold' && p.salePrice).reduce((sum, p) => sum + p.salePrice, 0);
    const totalCommission = products.filter(p => p.status === 'sold' && p.commission).reduce((sum, p) => sum + p.commission, 0);
    const totalNetToReceive = products.filter(p => p.status === 'sold' && p.netAmount).reduce((sum, p) => sum + p.netAmount, 0);

    return {
      available: availableCount,
      sold: soldCount,
      shipped: shippedCount,
      total: products.length,
      totalValue,
      totalSoldAmount,
      totalCommission,
      totalNetToReceive
    };
  };

  return {
    products,
    isLoading,
    addProduct,
    updateProductStatus,
    getProductsByStatus,
    getStats
  };
}