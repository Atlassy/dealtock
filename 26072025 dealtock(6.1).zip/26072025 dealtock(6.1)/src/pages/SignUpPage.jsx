import React from 'react';
import { Helmet } from 'react-helmet-async';
import SignUpForm from '@/components/auth/SignUpForm';

function SignUpPage() {
  return (
    <>
      <Helmet>
        <title>Inscription – Dealtock</title>
        <meta name="description" content="Créez votre compte Dealtock et commencez à optimiser votre logistique e-commerce." />
      </Helmet>
      <SignUpForm />
    </>
  );
}

export default SignUpPage;