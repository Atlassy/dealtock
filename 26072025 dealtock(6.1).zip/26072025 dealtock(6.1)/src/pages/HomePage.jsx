import React from 'react';
import { Helmet } from 'react-helmet-async';
import Header from '@/components/landing/Header';
import Hero from '@/components/landing/Hero';
import WhatWeDo from '@/components/landing/WhatWeDo';
import ForWhom from '@/components/landing/ForWhom';
import WhyChooseUs from '@/components/landing/WhyChooseUs';
import CTA from '@/components/landing/CTA';
import Footer from '@/components/landing/Footer';

function HomePage() {
  return (
    <>
      <Helmet>
        <title>Dealtock – Solutions innovantes pour l’e-commerce national</title>
        <meta name="description" content="Transformez vos retours et invendus en revenus passifs grâce à notre réseau de points de vente physiques et en ligne. Logistique e-commerce au Maroc." />
      </Helmet>
      <div className="flex flex-col min-h-screen bg-background">
        <Header />
        <main>
          <Hero />
          <WhatWeDo />
          <ForWhom />
          <WhyChooseUs />
          <CTA />
        </main>
        <Footer />
      </div>
    </>
  );
}

export default HomePage;