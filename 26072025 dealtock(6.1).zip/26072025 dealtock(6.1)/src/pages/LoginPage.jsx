import React from 'react';
import { Helmet } from 'react-helmet-async';
import LoginForm from '@/components/auth/LoginForm';

function LoginPage() {
  return (
    <>
      <Helmet>
        <title>Connexion – Dealtock</title>
        <meta name="description" content="Connectez-vous à votre compte Dealtock pour gérer vos produits." />
      </Helmet>
      <LoginForm />
    </>
  );
}

export default LoginPage;