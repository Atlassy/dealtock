import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Dashboard } from '@/components/Dashboard';
import { AdminDashboard } from '@/components/admin/AdminDashboard';
import { FullPageLoader } from '@/components/ui/loader';

function DashboardPage() {
  const { user, session, signOut } = useAuth();
  const [appLanguage, setAppLanguage] = useState('fr'); // Default language

  // The ProtectedRoute already ensures user is not null.
  // We might still want a loading state while fetching profile data.
  // For now, let's assume the user object from useAuth is sufficient.
  
  if (!user || !session) {
    return <FullPageLoader />;
  }
  
  // This logic should be improved to fetch profile from DB
  const mockUser = {
      id: user.id,
      email: user.email,
      name: user.user_metadata?.full_name || user.email.split('@')[0],
      company: 'Dealtock',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`,
      isAdmin: session.user.user_metadata?.role === 'admin'
  };

  return (
    <>
      <Helmet>
        <title>Tableau de bord – Dealtock</title>
        <meta name="description" content="Votre tableau de bord personnel Dealtock." />
      </Helmet>
      { mockUser.isAdmin ? (
          <AdminDashboard user={mockUser} onLogout={signOut} appLanguage={appLanguage} setAppLanguage={setAppLanguage} />
        ) : (
          <Dashboard user={mockUser} onLogout={signOut} appLanguage={appLanguage} setAppLanguage={setAppLanguage} />
      )}
    </>
  );
}

export default DashboardPage;